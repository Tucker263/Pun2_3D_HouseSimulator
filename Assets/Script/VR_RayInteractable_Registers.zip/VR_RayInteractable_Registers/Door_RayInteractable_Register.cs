using UnityEngine;
using UnityEngine.Events;
using System.Collections;
using System.Collections.Generic;

//ドアのRayInteractableを登録するクラス
public static class Door_RayInteractable_Register
{

    public static void register()
    {
        string registerTag = "door";
        List<GameObject> objList = NetworkObject_Search.GetListFromTag(registerTag);
       
        foreach (GameObject obj in objList)
        {
            AddWhenSelect(obj);
        }
    }

    //WhenSelectイベントを登録
    private static void AddWhenSelect(GameObject obj)
    {
        Door_ClickEvent d_cl = obj.GetComponent<Door_ClickEvent>();

        RayInteractableFactory.Create(obj, wrapper =>
        {
            wrapper.WhenSelect.AddListener(() =>
            {
                d_cl.Trigger();
            });

        });

    }

}
