using UnityEngine;
using UnityEngine.Events;
using System.Collections;
using System.Collections.Generic;

//窓のRayInteractableを登録するクラス
public static class Window_RayInteractable_Register
{

    public static void register()
    {
        string registerTag = "window";
        List<GameObject> objList = NetworkObject_Search.GetListFromTag(registerTag);

        foreach (GameObject obj in objList)
        {
            AddWhenSelect(obj);
        }
    }
    
    //WhenSelectイベントを登録
    private static void AddWhenSelect(GameObject obj)
    {
        Window_ClickEvent w_c = obj.GetComponent<Window_ClickEvent>();

        RayInteractableFactory.Create(obj, wrapper =>
        {
            wrapper.WhenSelect.AddListener(() =>
            {
                w_c.Trigger();
            });

        });

    }

}
