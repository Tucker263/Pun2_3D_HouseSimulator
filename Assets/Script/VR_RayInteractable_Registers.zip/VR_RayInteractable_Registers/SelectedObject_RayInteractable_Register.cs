using UnityEngine;
using UnityEngine.Events;
using System.Collections;
using System.Collections.Generic;

//SlectedObjectのRayInteractableを登録するクラス
public static class SelectedObject_RayInteractable_Register
{

    public static void register(string registerTag)
    {
        List<GameObject> objList = NetworkObject_Search.GetListFromTag(registerTag);

        foreach (GameObject obj in objList)
        {
            AddWhenSelect(obj);
        }
    }

    public static void registerFromObj(GameObject obj)
    {
        AddWhenSelect(obj);
    }
    
    //WhenSelectイベントを登録
    private static void AddWhenSelect(GameObject obj)
    {
        SelectedObject_ClickEvent s_c = obj.GetComponent<SelectedObject_ClickEvent>();

        RayInteractableFactory.Create(obj, wrapper =>
        {
            wrapper.WhenSelect.AddListener(() =>
            {
                s_c.Trigger();
            });

        });

    }

}
