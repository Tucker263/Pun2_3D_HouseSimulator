using UnityEngine;
using UnityEngine.Events;
using System.Collections;
using System.Collections.Generic;


//照明のRayInteractableを登録するクラス
public static class Lighting_RayInteractable_Register
{

    public static void register()
    {
        string registerTag = "lighting";
        List<GameObject> objList = NetworkObject_Search.GetListFromTag(registerTag);

        foreach (GameObject obj in objList)
        {
            AddWhenSelect(obj);
        }

    }
    
    //WhenSelectイベントを登録
    private static void AddWhenSelect(GameObject obj)
    {
        Lighting_ClickEvent l_ce = obj.GetComponent<Lighting_ClickEvent>();

        RayInteractableFactory.Create(obj, wrapper =>
        {
            wrapper.WhenSelect.AddListener(() =>
            {
                l_ce.Trigger();
            });

        });

    }

}
