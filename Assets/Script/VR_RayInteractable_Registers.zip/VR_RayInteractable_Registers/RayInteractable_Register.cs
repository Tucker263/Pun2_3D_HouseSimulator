using System.Collections;
using System.Collections.Generic;
using Photon.Pun;
using UnityEngine;

//RayInteractableを登録するクラス
public static class RayInteractable_Register
{

    public static void register()
    {
        //ドアのRayInteractableを登録
        Door_RayInteractable_Register.register();
        //窓のRayInteractableを登録
        Window_RayInteractable_Register.register();
        //照明のRayInteractableを登録
        Lighting_RayInteractable_Register.register();

        //家の天井、内壁、床、階段、外壁、屋根、家具のRayInteractableを登録
        List<string> selectedTag = new List<string>()
        {
            "ceiling", 
            "innerWall", 
            "floor",
            "stairs",
            "outerWall",
            "roof",
            "furniture"
        };
        foreach(string tag in selectedTag)
        {
            SelectedObject_RayInteractable_Register.register(tag);
        }

    }
    
}
