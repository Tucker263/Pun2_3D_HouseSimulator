using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SecondFloor_Movement : MonoBehaviour
{
    public GameObject CameraRig;
    private Transform CameraRig_tf;
    
    // Start is called before the first frame update
    void Start()
    {
        CameraRig_tf = CameraRig.GetComponent<Transform>();
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    
    public void Move()
    {
        CameraRig_tf.position = new Vector3(2, 4, 18);
    }
}
