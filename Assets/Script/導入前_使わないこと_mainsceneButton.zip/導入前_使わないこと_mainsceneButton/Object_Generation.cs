using System.Collections;
using System.Collections.Generic;
using Photon.Pun;
using UnityEngine;
using System;


public class Object_Generation : MonoBehaviour
{
    //public GameObject Object;
    public string objectName;
    public GameObject CameraRig;
    public GameObject CenterEyeAnchor;
    public float Length;
    private Transform camera_tf;
    private Transform centerEye_tf;
    // Start is called before the first frame update
    void Start()
    {
        camera_tf = CameraRig.GetComponent<Transform>();
        centerEye_tf = CenterEyeAnchor.GetComponent<Transform>();
    }

    // Update is called once per frame
    void Update()
    {

    }

    public void GenrateObject()
    {
        /*
        //自分がどんな方向を見ても、自分に対して正面にオブジェクトを生成
        double RadianY = Math.PI * centerEye_tf.eulerAngles.y / 180.0;
        float LengthX = (float)(Length * Math.Sin(RadianY));
        float LengthZ = (float)(Length * Math.Cos(RadianY));
        GameObject ObjectClone = Instantiate(Object, new Vector3(camera_tf.position.x + LengthX, camera_tf.position.y + 3, camera_tf.position.z + LengthZ), Quaternion.identity);
        ObjectClone.transform.LookAt(camera_tf);
        */

        Debug.Log("オブジェクトの生成処理");
        //自分がどんな方向を見ても、自分に対して正面にオブジェクトを生成
        double RadianY = Math.PI * centerEye_tf.eulerAngles.y / 180.0;
        float LengthX = (float)(Length * Math.Sin(RadianY));
        float LengthZ = (float)(Length * Math.Cos(RadianY));
        var position = new Vector3(camera_tf.position.x + LengthX, camera_tf.position.y + 3, camera_tf.position.z + LengthZ);
        PhotonNetwork.Instantiate(objectName, position, Quaternion.identity);

        //生成したオブジェクトが自分の方向に向く処理がわからない???

    }
}
