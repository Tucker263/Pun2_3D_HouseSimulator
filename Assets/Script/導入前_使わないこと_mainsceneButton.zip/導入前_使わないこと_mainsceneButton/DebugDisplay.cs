using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DebugDisplay : MonoBehaviour
{
    //ダブルクリック判別用
    private float lastClickTime = 0f;
    private float doubleClickThreshold = 0.3f;

    public GameObject menuBar;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void Display()
    {
        /*
        Debug.Log("aaaaaaaaaaaaaaaaaaaaaaaaaa");
        GameObject obj = this.gameObject;
        MenuBar_Transition m_t = obj.GetComponent<MenuBar_Transition>();
        m_t.Transition();*/

        /*//ダブルクリックは成功した
        float timeSinceLastClick = Time.time - lastClickTime;
        if (timeSinceLastClick <= doubleClickThreshold)
        {
            Debug.Log("ダブルクリック");
            GameObject obj = this.gameObject;
            MenuBar_Transition m_t = obj.GetComponent<MenuBar_Transition>();
            m_t.Transition();

        }
        lastClickTime = Time.time;
        */

        if (OVRInput.GetDown(OVRInput.RawButton.Start)){
            menuBar.SetActive(menuBar.activeSelf ? false : true);
        }

    }
}
