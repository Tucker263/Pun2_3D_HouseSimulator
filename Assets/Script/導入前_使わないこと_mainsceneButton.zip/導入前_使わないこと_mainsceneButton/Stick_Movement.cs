using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Stick_Movement : MonoBehaviour
{

    public GameObject CameraRig;
    public GameObject CenterEyeAnchor;
    public float move_speed;
    private float stick_sensitivity;
    private Transform camera_tf;
    private Transform centerEye_tf;

    // Start is called before the first frame update
    void Start()
    {
        //スティックの感度が強すぎるため、感度を10分の1に
        stick_sensitivity = 0.1f;
        camera_tf = CameraRig.GetComponent<Transform>();
        centerEye_tf = CenterEyeAnchor.GetComponent<Transform>();
    }

    // Update is called once per frame
    void Update()
    {
        //左スティックで移動
        Move();
        //右スティックで視点移動
        ChangeDirection();
    }

    void Move(){
        //左手のアナログスティックの向きを取得
        Vector2 stickL = OVRInput.Get(OVRInput.RawAxis2D.LThumbstick);
        Vector3 changePosition = new Vector3((stickL.x * move_speed * stick_sensitivity), 0, (stickL.y * move_speed * stick_sensitivity));

        //cameraRigの角度の誤差を修正
        float angle_y = camera_tf.eulerAngles.y;
        //HMDのY軸の角度取得
        Vector3 changeRotation = new Vector3(0, centerEye_tf.eulerAngles.y - angle_y, 0);
        //CameraRigの位置変更
        camera_tf.position += camera_tf.rotation * (Quaternion.Euler(changeRotation) * changePosition);
    }
    
    void ChangeDirection(){
        //右手のアナログスティックの向きを取得
        Vector2 stickR = OVRInput.Get(OVRInput.RawAxis2D.RThumbstick);
        float angle_x= stickR.x;
        //CameraRigの角度変更
        camera_tf.Rotate(0, angle_x, 0);
    }
}
