using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Sun_Movement : MonoBehaviour
{
    public GameObject Sun;
    private Slider slider;
    private Transform Sun_tf;
    // Start is called before the first frame update
    void Start()
    {
        slider = GetComponent<Slider>();
        Sun_tf = Sun.GetComponent<Transform>();
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void Move()
    {
        float SunRotateX = slider.value;
        Sun_tf.eulerAngles = new Vector3(SunRotateX, 0, 0);
    }
}
