using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using UnityEngine.UI;
using TMPro;


public class Matrials_Setting : MonoBehaviour
{
    public Material material2;
    public MaterialList materialList;
    public GameObject originHouse;
    public GameObject toggleContent;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    
    public void SetMaterials(Material material = null)
    {
        //方針:houseColorのボタン名とアクティブかどうかを取得して、マテリアルをアセットから検索
        //houseColorのcontentを取得
        //for文でbuttonがオンの物を探す
        //buttonのテキストを取得
        //マテリアルをアセットから検索
        //smallHouseにそのマテリアルをセット

        GameObject button = null;
        for (int i = 0; i < toggleContent.transform.childCount; i++)
        {
            GameObject current = toggleContent.transform.GetChild(i).gameObject;
            if (current.GetComponent<Toggle>().isOn)
            {
                button = current;
                break;
            }
        }
        if(button == null) return;
        TextMeshProUGUI text = button.GetComponentInChildren<TextMeshProUGUI>();
        String materialName = text.text;
        //マテリアルリストからテキストを使ってマテリアルを検索
        for (var i = 0; i < materialList.materialslist.Count; i++)
        {
            if (materialName == materialList.materialslist[i].name)
            {
                Material[] tmp = gameObject.GetComponent<MeshRenderer>().materials;
                for (int j = 0; j < tmp.Length; j++)
                {
                    tmp[j] = materialList.materialslist[i];
                }

                gameObject.GetComponent<MeshRenderer>().materials = tmp;
                //もう少し考える
                GameObject.FindWithTag("wall").GetComponent<MeshRenderer>().materials = tmp;
                //originHouse.transform.Find(gameObject.name).GetComponent<MeshRenderer>().materials = tmp;
            }
        }
    }
}
